from discord.ext import commands
import discord
import os
from useful import logger
from useful import util_box

import openpyxl
import random

class Unit:
    name = None
    hp = None
    min_damage = None
    max_damage = None
    depence = None
    evsation = None
    speed = None

    def attack(self, enemy_hp, enemy_depence, enemy_evsation):
        evsation = random.radint(1, 100)
        
        if evsation <= enemy_evsation:
            attack_damage = 0

        attack_damage = random.randint(self.min_damage, self.max_damage) - enemy_depence

        if attack_damage <= 0:
            attack_damage = 0
        
        return enemy_hp - attack_damage

class Red_1(Unit):
    name = None
    hp = None
    min_damage = None
    max_damage = None
    depence = None
    evsation = None
    speed = None

    
class DuelCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def 결투(self, ctx, arg):
        user_file = openpyxl.load_workbook("DB.xlsx")
        user_sheet = user_file.active

        first_userID = 0
        while True:
            first_userID = first_userID + 1
            if user_sheet["A" + str(first_userID)].value == str(ctx.author.id):
                break
        
        second_userID = 0
        while True:    
            second_userID = second_userID + 1
            if user_sheet["B" + str(second_userID)].value == arg:
                break
            elif second_userID == 100:
                await ctx.send(f'{arg}을/를 찾을 수 없어.')
                return 0

        ###임의의 스텟
        red1_name = 'red1'
        red1_min_damage = 10
        red1_max_damage = 20
        red1_hp = 30
        red1_speed = 1
        red1_def = 10
        red1_evasion = 10
        
        red2_name = 'red2'
        red2_min_damage = 10
        red2_max_damage = 20
        red2_hp = 30
        red2_speed = 2
        red2_def = 5
        red2_evasion = 10
        
        red3_name = 'red3'
        red3_min_damage = 10
        red3_max_damage = 20
        red3_hp = 30
        red3_speed = 3
        red3_def = 5
        red3_evasion = 10

        blue1_name = 'blue1'
        blue1_min_damage = 10
        blue1_max_damage = 20
        blue1_hp = 30
        blue1_speed = 4
        blue1_def = 10
        blue1_evasion = 10
        
        blue2_name = 'blue2'
        blue2_min_damage = 10
        blue2_max_damage = 20
        blue2_hp = 30
        blue2_speed = 5
        blue2_def = 5
        blue2_evasion = 10
        
        blue3_name = 'blue3'
        blue3_min_damage = 10
        blue3_max_damage = 20
        blue3_hp = 30
        blue3_speed = 6
        blue3_def = 5
        blue3_evasion = 10

        fish = [[red1_name, red1_min_damage, red1_max_damage, red1_hp, red1_speed, red1_def, red1_evasion, 'red', 1, 0],
                [red2_name, red2_min_damage, red2_max_damage, red2_hp, red2_speed, red2_def, red2_evasion, 'red', 2, 0],
                [red3_name, red3_min_damage, red3_max_damage, red3_hp, red3_speed, red3_def, red3_evasion, 'red', 3, 0],
                [blue1_name, blue1_min_damage, blue1_max_damage, blue1_hp, blue1_speed, blue1_def, blue1_evasion, 'blue', 4, 0],
                [blue2_name, blue2_min_damage, blue2_max_damage, blue2_hp, blue2_speed, blue2_def, blue2_evasion, 'blue', 5, 0],
                [blue3_name, blue3_min_damage, blue3_max_damage, blue3_hp, blue3_speed, blue3_def, blue3_evasion, 'blue', 6, 0]
                ]
        
        fish_stat = sorted(fish, key=lambda x : x[4], reverse = True)
        
        embed = discord.Embed(title = '결투 준비', description = '10초 후 결투가 시작됩니다.', color = 0x1AEADB)
        embed.add_field(name="red팀 1번", value=red1_name, inline=True)
        embed.add_field(name="red팀 2번", value=red2_name, inline=True)
        embed.add_field(name="red팀 3번", value=red3_name, inline=True)      
        embed.add_field(name="blue팀 1번", value=blue1_name, inline=True)
        embed.add_field(name="blue팀 2번", value=blue2_name, inline=True)
        embed.add_field(name="blue팀 3번", value=blue3_name, inline=True)
        await ctx.send(embed=embed)

        turn = -1
        while True:
            
            turn = turn + 1

            if turn == 6:
                turn = 0
                
            red_team = [1,2,3]
            blue_team = [4,5,6]

            
            for w in range(0, 6):
                if fish_stat[w][9] == 1 and fish_stat[w][7] == 'red':
                    del red_team[int(fish_stat[w][8]) - 1]
                    
                elif fish_stat[w][9] == 1 and fish_stat[w][7] == 'blue':
                    del blue_team[int(fish_stat[w][8]) - 4]

            if len(red_team) == 0:
                await ctx.send(f'블루팀이 승리했습니다.')
                return 0
            elif len(blue_team) == 0:
                await ctx.send(f'레드팀이 승리했습니다.')
                return 0
                    
                
            
            if fish_stat[turn][7] == 'red':
                choice = random.choice(blue_team) #4,5,6
            elif fish_stat[turn][7] == 'blue':
                choice = random.choice(red_team) #1,2,3
            else:
                await ctx.send('버그 발생')
                return 0

            
                    

            i = -1
            while True:
                i = i + 1
                if fish_stat[i][8] == choice:
                    
                    if fish_stat[turn][9] == 1:
                        break
                    
                    evasion = random.randint(1,100)
                    attack_damage = random.randint(fish_stat[turn][1], fish_stat[turn][2]) - fish_stat[i][5]
                    
                    if attack_damage <= 0:
                        attack_damage = 0
    
                    elif fish_stat[i][6] >= evasion:
                        attack_damage = 0

                    else:
                        pass
                    
                    fish_stat[i][3] = fish_stat[i][3] - attack_damage

                    if fish_stat[i][3] <= 0:
                        fish_stat[i][9] = 1
                        
                    await ctx.send(f'{fish_stat[turn][0]}이/가 {fish_stat[i][0]}에게 {attack_damage}의 데미지를 주었다. 남은체력: {fish_stat[i][3]}')
                    break

            


        print(fish_stat)

def setup(bot):
    logger.info(f'{os.path.abspath(__file__)} 로드 완료')
    bot.add_cog(DuelCog(bot))  # 꼭 이렇게 위의 클래스를 이렇게 add_cog해 줘야 작동해요!
