import discord
from discord.ext import commands
import os
from useful import logger

from bs4 import BeautifulSoup
import requests

from PIL import Image, ImageDraw, ImageFont
import textwrap


class WeatherCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    
    @commands.command(name='날씨')
    async def weather(self, ctx, arg):
        location = arg+'날씨'
        html = requests.get('https://search.naver.com/search.naver?query=' + location)
        soup = BeautifulSoup(html.text, 'html.parser')

        main_data = soup.find('div', {'class': 'weather_box'})

        find_weather = main_data.find('p', {'class': 'cast_txt'}).text #날씨 (맑음, 흐림)
        find_address = main_data.find('span', {'class':'btn_select'}).text #위치
        find_currenttemp = main_data.find('span',{'class': 'todaytemp'}).text #온도

        CheckDust = []
        
        CheckDust1 = soup.find('div', {'class': 'sub_info'})
        CheckDust2 = CheckDust1.find('div', {'class': 'detail_box'})
        for i in CheckDust2.select('dd'):
            CheckDust.append(i.text)
        FineDust = CheckDust[0][:-2] + " " + CheckDust[0][-2:]
        UltraFineDust = CheckDust[1][:-2] + " " + CheckDust[1][-2:]
        Ozon = CheckDust[2][:-2] + " " + CheckDust[2][-2:]

        
        if find_weather[:2] == '맑음' :
            main_image = Image.open('C:/Users/user/Desktop/Test_bot/rsc/weather/img/img_sunny.jpg')
        elif find_weather[:2] == '흐림':
            main_image = Image.open('C:/Users/user/Desktop/Test_bot/rsc/weather/img/img_cloud.jpg')
        elif find_weather[:2] == '구름':
            main_image = Image.open('C:/Users/user/Desktop/Test_bot/rsc/weather/img/img_cloud.jpg')  
        elif find_weather[:2] == '비,':
            main_image = Image.open('C:/Users/user/Desktop/Test_bot/rsc/weather/img/img_rainy.jpg')
        else:
            pass
            

        fontsFolder = 'C:/Users/user/Desktop/Test_bot/rsc/weather/font' 
        temperatureFont =ImageFont.truetype(os.path.join(fontsFolder,'NotoSansKR-Black.otf'),270)
        addressFont =ImageFont.truetype(os.path.join(fontsFolder,'NanumGothicExtraBold.ttf'),75)
        sub_dataFont =ImageFont.truetype(os.path.join(fontsFolder,'NanumSquareRoundR.ttf'),60)

        draw =ImageDraw.Draw(main_image)
        draw.text((550,180),find_currenttemp + "℃",fill="black",font=temperatureFont,align='center')
        draw.text((650,50),find_address,fill="black",font=addressFont,align='center')
        draw.text((1198,260),"미세먼지     " + FineDust,fill="black",font=sub_dataFont,align='center')
        draw.text((1200,350),"초미세먼지 " + UltraFineDust,fill="black",font=sub_dataFont,align='center')
        draw.text((1198,440),"오존       " + Ozon,fill="black",font=sub_dataFont,align='center')
        

        main_image.save("C:/Users/user/Desktop/Test_bot/rsc/weather/result.jpg")
        logger.info(f'오늘의 날씨 업로드 완료')
                    
        files = discord.File("C:/Users/user/Desktop/Test_bot/rsc/weather/result.jpg")
        await ctx.send(file=files)


def setup(bot):
    logger.info(f'{os.path.abspath(__file__)} 로드 완료')
    bot.add_cog(WeatherCog(bot))  # 꼭 이렇게 위의 클래스를 이렇게 add_cog해 줘야 작동해요!
