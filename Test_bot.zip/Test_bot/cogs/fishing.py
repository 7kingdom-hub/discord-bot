import discord
from discord.ext import commands
import os
from useful import logger
from useful import util_box
import bot_config

import openpyxl
import random


class FishingCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

               
    @commands.command()      
    async def 예(self, ctx):
        user_file = openpyxl.load_workbook("DB.xlsx")
        user_sheet = user_file.active

        userID = 0
        while True:
            userID = userID + 1
            if user_sheet["A" + str(userID)].value == str(ctx.author.id):
                break

        #sheet.close()

        
        fish_file = openpyxl.load_workbook("fish_DB.xlsx")
        fish_sheet = fish_file.active

        fish_kinds = []

        if ctx.channel.id == 841303610566639636:
            i = 0
            while True:
                i = i + 1
                if fish_sheet["A" + str(i)].value == None:
                    w = i - 1
                    catch_ = random.randint(2,w)
                    catch_fish = fish_sheet["B" + str(catch_)].value
                    break
        
        elif ctx.channel.id == 840977127058702386:
            i = 0
            while True:
                i = i + 1
                if fish_sheet["C" + str(i)].value == '바다':
                    fish_kinds.append(fish_sheet["B" + str(i)].value)

                elif fish_sheet["A" + str(i)].value == 'END':
                    catch_fish = random.choice(fish_kinds)
                    break
                    
        
        elif ctx.channel.id == 840977204938670130:
            i = 0
            while True:
                i = i + 1
                if fish_sheet["C" + str(i)].value == '호수':
                    fish_kinds.append(fish_sheet["B" + str(i)].value)

                elif fish_sheet["A" + str(i)].value == 'END':
                    catch_fish = random.choice(fish_kinds)
                    break
        
        elif ctx.channel.id == 840977228632555520:
            i = 0
            while True:
                i = i + 1
                if fish_sheet["C" + str(i)].value == '강':
                    fish_kinds.append(fish_sheet["B" + str(i)].value)

                elif fish_sheet["A" + str(i)].value == 'END':
                    catch_fish = random.choice(fish_kinds)
                    break
        
        else:
            await ctx.send(f'여기는 낚시터가 아니야!')
            return 0

            
        fishID = 0
        while True:
            fishID = fishID + 1
            if fish_sheet["B" + str(fishID)].value == catch_fish:
                catch_fish_image = fish_sheet["D" + str(fishID)].value
                grade = fish_sheet["E" + str(fishID)].value
                position = fish_sheet["F" + str(fishID)].value
                min_damage = fish_sheet["G" + str(fishID)].value
                max_damage = fish_sheet["H" + str(fishID)].value
                hp = fish_sheet["I" + str(fishID)].value
                depence = fish_sheet["J" + str(fishID)].value
                evasion = fish_sheet["K" + str(fishID)].value
                speed = fish_sheet["L" + str(fishID)].value
                break
                
        print(catch_fish)

        if grade == '일반':
            honor_point = 1
        elif grade == '희귀':
            honor_point = 3
        elif grade == '특급':
            honor_point = 6
        elif grade == '전설':
            honor_point = 10
        else:
            honor_point = 0

        warning = '```※ 느낌이 오면 \U0001F3A3를 연타하자! \n(그만하려면 \U0001F6AB를 누르자)```'
        script_ = ['물고기를 누르지마!', '날씨가 좋네','파동이 일고 있다.','편안하구만!']
        
        embed = discord.Embed(title = '낚시를 시작해볼까?' , description = warning, color = 0x00FF13)
        fishing = await ctx.send(embed = embed)
        result = await util_box.wait_for_reaction(self.bot, fishing, ['\U0001F3A3', '\U0001F6AB'], 3 , ctx)
        
        s = 1
        while True:
            asd = 3# random.randint(1,4)
            
            if asd != 3:
                script = random.choice(script_)
    
                embed = discord.Embed(title = '기다리는 중...' , description =script + warning, color = 0x1AEADB)
                await fishing.edit(embed=embed)
                result = await util_box.wait_for_reaction(self.bot, fishing, ['\U0001F3A3', '\U0001F6AB'], 2 , ctx)

                if not result:
                    s = s + 1
                    if s == 5:
                        embed = discord.Embed(title = '낚시 실패',description = '물고기가 오지 않는다.', color = 0x999999)
                        await fishing.clear_reactions()
                        await fishing.edit(embed=embed)
                        break
                    
                elif result.emoji == '\U0001F3A3':
                    embed = discord.Embed(title = '낚시 실패', description = '너무 빨리 낚았다..', color = 0x999999)
                    await fishing.clear_reactions()
                    await fishing.edit(embed=embed)
                    break
            
                else:
                    embed = discord.Embed(title = '낚시 중지', descrieiption = '낚싯대를 감아 정리했다.', color = 0x999999)
                    await fishing.clear_reactions()
                    await fishing.edit(embed=embed)
                    break

            elif asd == 3:
                embed = discord.Embed(title = '물고기가 문 것 같아!', description = warning, color = 0xFF0000)
                await fishing.edit(embed=embed)
                result = await util_box.wait_for_reaction(self.bot, fishing, ['\U0001F3A3', '\U0001F6AB'], 3 , ctx)

                if not result:
                    embed = discord.Embed(title = '낚시 실패', description = '물고기가 도망갔다.', color = 0x999999)
                    await fishing.clear_reactions()
                    await fishing.edit(embed=embed)
                    break
                elif result.emoji == '\U0001F3A3':
                    embed = discord.Embed(title = '낚시 성공', description = f'{catch_fish}을(를) 잡았다.', color = 0x1AEADB)
                    embed.add_field(name="등급", value=grade, inline=True)
                    embed.add_field(name="역할군", value=position, inline=False)
                    embed.add_field(name="최소공격력", value=min_damage, inline=True)
                    embed.add_field(name="최대공격력", value=max_damage, inline=True)
                    embed.add_field(name="체력", value=hp, inline=True)
                    embed.add_field(name="방어력", value=depence, inline=True)
                    embed.add_field(name="회피력", value=evasion, inline=True)
                    embed.add_field(name="스피드", value=speed, inline=True)
                    embed.set_thumbnail(url=catch_fish_image)
                    await fishing.clear_reactions()
                    await fishing.edit(embed=embed)

                    choice = await util_box.wait_for_reaction(self.bot, fishing, [ '\U0001F41F', '\U0001F44D'], 5 , ctx)

                    if not choice:
                        user_sheet["F" + str(userID)].value = user_sheet["F" + str(userID)].value + honor_point
                        await fishing.delete()
                        await ctx.send(f'`{catch_fish}`을/를 방생해서 `{honor_point}`만큼 명예가 늘었습니다')
                        user_file.save("DB.xlsx")
                        break
                    
                    elif choice.emoji == '\U0001F41F':
                        await fishing.delete()

                        catch_fish_sheet = user_file[user_sheet["B" + str(userID)].value]

                        i = 0
                        while True:
                            i = i + 1
                            if catch_fish_sheet["A" + str(i)].value == None:
                                catch_fish_sheet["A" + str(i)].value = fish_sheet["B" + str(fishID)].value
                                break

                        catch_fish_sheet["B" + str(i)].value = max_damage
                        catch_fish_sheet["C" + str(i)].value = min_damage
                        catch_fish_sheet["D" + str(i)].value = hp
                        catch_fish_sheet["E" + str(i)].value = depence
                        catch_fish_sheet["F" + str(i)].value = evasion
                        catch_fish_sheet["G" + str(i)].value = speed
                        catch_fish_sheet["H" + str(i)].value = 0

                        
                                
                        
                        user_file.save("DB.xlsx")
                        await ctx.send(f'`{catch_fish}`을/를 어장에 보관했어.')
                        break
                    else:
                        user_sheet["F" + str(userID)].value = user_sheet["F" + str(userID)].value + honor_point
                        await fishing.delete()
                        await ctx.send(f'`{catch_fish}`을/를 방생해서 `{honor_point}`만큼 명예가 늘었습니다')
                        user_file.save("DB.xlsx")
                        break

                else:
                    embed = discord.Embed(title = '낚시 중지', descrieiption = '낚싯대를 감아 정리했다.', color = 0x999999)
                    await fishing.clear_reactions()
                    await fishing.edit(embed=embed)
                    break



def setup(bot):
    logger.info(f'{os.path.abspath(__file__)} 로드 완료')
    bot.add_cog(FishingCog(bot))  # 꼭 이렇게 위의 클래스를 이렇게 add_cog해 줘야 작동해요!
