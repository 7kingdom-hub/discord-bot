from discord.ext import commands
import discord
import os
from useful import logger

from useful import util_box
import openpyxl

class Fish_netCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.command()
    async def 내어망(self, ctx):
        user_file = openpyxl.load_workbook("DB.xlsx")
        user_sheet = user_file.active

        userID = 0
        while True:
            userID = userID + 1
            if user_sheet["A" + str(userID)].value == str(ctx.author.id):
                break
            
        catch_fish_sheet = user_file[user_sheet["B" + str(userID)].value]


        i = 1
        max_damage = catch_fish_sheet["B" + str(i)].value
        min_damage = catch_fish_sheet["C" + str(i)].value 
        hp = catch_fish_sheet["D" + str(i)].value
        depence = catch_fish_sheet["E" + str(i)].value
        evasion = catch_fish_sheet["F" + str(i)].value
        speed = catch_fish_sheet["G" + str(i)].value
        
        
        embed = discord.Embed(title = '내어망', color = 0x00FF13)

        embed.add_field(name="최소공격력", value=min_damage, inline=True)
        embed.add_field(name="최대공격력", value=max_damage, inline=True)
        embed.add_field(name="체력", value=hp, inline=True)
        embed.add_field(name="방어력", value=depence, inline=True)
        embed.add_field(name="회피력", value=evasion, inline=True)
        embed.add_field(name="스피드", value=speed, inline=True)
        fish_net = await ctx.send(embed = embed)
        
        result = await util_box.wait_for_reaction(self.bot, fish_net, ['⬅', '1️⃣', '2️⃣' ,'3️⃣' ,'➡'], 3 , ctx)
        


def setup(bot):
    logger.info(f'{os.path.abspath(__file__)} 로드 완료')
    bot.add_cog(Fish_netCog(bot))  # 꼭 이렇게 위의 클래스를 이렇게 add_cog해 줘야 작동해요!
