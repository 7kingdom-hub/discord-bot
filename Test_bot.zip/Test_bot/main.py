import datetime
import os

import discord
from discord.ext import commands

from bot_config import bot_config
from useful import logger




class BambooBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix=bot_config.prefixes,  # 접두사는 config.py에서 설정
            help_command=None
        )

        # Cogs 로드(Cogs 폴더 안에 있는 것이라면 자동으로 인식합니다)
        cog_list = [i[:-3] for i in os.listdir('cogs') if i.endswith('.py') and i != '__init__.py']
        self.add_cog(AdminCog(self))  # 기본 제공 명령어 Cog
        for i in cog_list:
            self.load_extension(f"cogs.{i}")    


    async def on_ready(self):  # 봇이 구동되면 실행
        logger.info('======================')
        logger.info('< 구동 완료 >')
        logger.info(f'봇 이름 : {self.user.name}')
        logger.info(f'봇 버전 : {bot_config.version}')
        logger.info(f'봇 아이디 : {self.user.id}')
        logger.info('======================')

        await self.change_presence(
            status=discord.Status.online,  # 상태 설정
            activity=discord.Game(name=bot_config.activity))  # 하고 있는 게임으로 표시되는 것 설정

    def run(self):
        super().run(bot_config().using_token(), reconnect=True)
        
class AdminCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    # cogs 폴더 안의 코드를 수정했다면 굳이 껐다 키지 않아도 다시시작 명령어로 적용이 가능해!
    @commands.command(name='')
    async def restart(self, ctx):
        if ctx.author.id not in bot_config.admin:
            return await ctx.send(
                '권한이 없습니다.'
                '\n`❗ 봇 관리자라면 admin 리스트에 디스코드 ID를 추가하여주십시오`')

        w = await ctx.send("```모듈을 다시 불러오는 중...```")
        cog_list = [i[:-3] for i in os.listdir('cogs') if i.endswith('.py') and i != 'cogs.__init__.py']
        for i in cog_list:
            self.bot.reload_extension(f"cogs.{i}")
            logger.info(f"'{i}' 다시 불러옴")

        await w.edit(content="```cs\n'불러오기 성공'```")

        
BambooBot = BambooBot()
BambooBot.run()
