import asyncio
import random
import emoji

async def wait_for_reaction(bot, window, emojis, timeout, ctx, event='reaction_add', add_react=True):
    '''지정한 이모지가 눌릴 때까지 기다린 후 눌림 여부에 따라 Bool 방식 반환
    - 시간 초과는 False 반환'''
    if add_react:
        for i in list(emojis):
            await window.add_reaction(i)

    def check(reaction, user):
        if user == ctx.author and str(reaction.emoji) in emojis and reaction.message.id == window.id:
            return True
        else:
            return False

    try:
        reaction = await bot.wait_for(event, timeout=timeout, check=check)

    except asyncio.TimeoutError:
        return False

    else:
        return reaction[0]


async def wait_for_saying(bot, timeout, ctx, keyword='', user=None):
    if user is None:
        for_user = ctx.author
    else:
        for_user = user

    def check(m):
        if m.author == for_user and keyword in m.content:
            return True
        else:
            return False

    try:
        msg = await bot.wait_for('message', timeout=timeout, check=check)

    except asyncio.TimeoutError:
        return False

    else:
        return msg


def rdpc(percentage):
    '''RanDom PerCents
    퍼센트를 넣으면 그 확률로 Bool 뱉음'''
    F = random.randrange(1, 101)
    if F <= percentage:
        return True
    else:
        return False
