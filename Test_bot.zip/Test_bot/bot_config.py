class bot_config:
    # 봇의 토큰
    token = 'ODIwMTg2Nzk4NjIxMTk2MzA5.YExgew.D0r3ItyHz9kOJbvBseOFWqnyYXQ'
    
    # 디버그 모드용 토큰
    test_token = 'ODIwMTg2Nzk4NjIxMTk2MzA5.YExgew.D0r3ItyHz9kOJbvBseOFWqnyYXQ'

    # 디버그 여부
    is_debug = False

    # 하고 있는 게임 (... 하는 중)
    activity = "대나무 꽃 수분"

    # 접두사
    prefixes = ['!']

    # 봇의 버전
    version = '1.0'

    sea_fishing_place = '840977127058702386'

    river_fishing_place = '840977204938670130'

    lake_fishing_place = '840977228632555520'
        
    # 관리자 디스코드 id 목록
    admin = [342209486175338505]

    # 사용할 토큰 반환
    def using_token(self):
        return self.test_token if self.is_debug else self.token
        ''' if self.is_debug:
                    return self.test_token
                else:
                    return self.token'''
    
